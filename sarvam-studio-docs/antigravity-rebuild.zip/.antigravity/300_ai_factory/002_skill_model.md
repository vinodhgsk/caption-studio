# Skill Model
A skill is reusable capability knowledge (a `SKILL.md` with a name/description frontmatter and a body of
purpose, interfaces/schemas, conventions, and a determinism/parity note). Skills encode the how-to that
multiple agents share — text rendering, caption sync, forced alignment, indic-text, transliteration,
storage, ffmpeg/export, preset store. Skills are contracts, not code: they define interfaces and
invariants (e.g. grapheme-cluster atomicity, seeded determinism, headless parity) that agents implement.
Adding a skill is additive and never rewrites existing ones.
