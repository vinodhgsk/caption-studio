# 300_ai_factory
Caption Studio is built by an AI pipeline (the `.claude/` setup): specialist agents, reusable skills,
slash commands, and hooks, driven by an autopilot runbook and a build-state tracker. This package is the
governing knowledge for that pipeline — the conventions agents/skills/commands/hooks must follow so the
build is reproducible, gated, and consistent with the product (100) and engineering (200) knowledge.
