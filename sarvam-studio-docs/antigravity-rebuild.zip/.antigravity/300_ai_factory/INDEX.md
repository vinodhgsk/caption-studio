# 300_ai_factory — Index
- 001_agent_model.md — specialist agent conventions (scope, ownership, done-when)
- 002_skill_model.md — reusable skill conventions (SKILL.md, contracts, parity)
- 003_command_hook_model.md — slash commands + quality-gate hooks
- 004_autopilot_runbook_model.md — the runbook + build-state orchestration model
