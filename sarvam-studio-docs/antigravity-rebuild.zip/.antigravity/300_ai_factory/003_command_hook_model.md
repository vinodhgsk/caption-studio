# Command & Hook Model
Slash commands are entry points (scaffold, build-phase, build-feature, autopilot, parity-check,
preview-library, gen-preset). Hooks enforce quality automatically: a post-edit hook typechecks/lints
changed files; a Stop/gate hook runs the full test suite (and parity/Indic checks) before a step is
marked done. The gate is the mechanical embodiment of the engineering testing standard (200/005) and the
foundation validation principle (000): no build step advances past a failing gate. Commands and hooks are
additive; new hooks are registered without modifying existing ones (or invoked explicitly).
