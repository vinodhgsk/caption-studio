# Autopilot Runbook Model
The build is expressed as an ordered runbook of atomic, checkbox-tracked prompts grouped into phases,
each prompt tagged with its owning agent and the spec it implements. An orchestrator reads a build-state
file, dispatches the next prompt to its agent, runs the gate, marks it done, and advances — stopping at
phase milestones for human verification. State and runbook are data; the spec docs (100/200) are the
"what". Advanced/expansion tracks layer additively via their own runbook + state + orchestrator, never
mutating the core ones. This model is how product knowledge becomes a running application.
