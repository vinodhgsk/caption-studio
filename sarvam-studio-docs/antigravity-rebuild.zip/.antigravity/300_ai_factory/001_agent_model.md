# Agent Model
An agent owns a bounded slice of the build and is dispatched by an orchestrator. Convention: a concise
descriptor (name, one-line ownership, tools) plus a paragraph stating what it implements, which skills and
data-model contracts it uses, the Indic/parity rules it must honor, and an explicit "Done when". Agents
write only into declared schema slots and never modify frozen artifacts. They are additive: new agents are
new files, auto-discovered. This package governs the roster (caption, text, effects, transitions, storage,
export, QA, orchestration) that builds the product; each agent conforms to 000_foundation and implements
100/200 knowledge.
