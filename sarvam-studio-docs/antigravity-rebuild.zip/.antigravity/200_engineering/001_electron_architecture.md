# Electron Architecture
Three processes with a strict boundary. **Main** owns all privileged work — filesystem, FFmpeg,
STT/forced-alignment, TTS, storage, OneDrive/Graph. **Preload** is the only bridge: it exposes a narrow,
typed `window.api` via contextBridge (contextIsolation on, nodeIntegration off, sandbox on) and never
leaks raw ipcRenderer. **Renderer** is React/TypeScript UI only — timeline, preview compositor, panels.
All cross-process calls are typed IPC returning an `{ ok, error }` envelope; handlers never throw across
the boundary. This boundary is what keeps the app secure and testable and lets the render pipeline run
headless for export parity (004).
