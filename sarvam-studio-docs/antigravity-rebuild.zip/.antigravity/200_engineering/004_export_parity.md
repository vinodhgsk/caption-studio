# Export Parity (a hard contract)
The preview and the FFmpeg export MUST produce identical frames, to the frame. This is achievable only if
the text/compositor render pipeline is headless-capable (no DOM-only paths) and deterministic: any
randomness (glitch, jitter, particles) is seeded from (clipId, frameIndex); audio-reactivity and forced
alignment read precomputed, frame-indexed caches rather than sampling live. Times are frame-snapped once,
on emit. A render-parity check samples exported frames against the headless render within a threshold and
fails the build on divergence. This contract binds 100_product_captioning (styles/effects/karaoke) and is
verified by 400_governance quality gates.
