# 200_engineering — Index
- 001_electron_architecture.md — main/preload/renderer, typed IPC {ok,error}
- 002_project_bundle_model.md — the .vproj bundle + project.json contract
- 003_storage_local_onedrive.md — StorageProvider (local + OneDrive synced/Graph)
- 004_export_parity.md — preview == FFmpeg export, to the frame
- 005_testing_standard.md — unit/e2e, determinism, the quality gate
- diagrams/electron_process_model.drawio
