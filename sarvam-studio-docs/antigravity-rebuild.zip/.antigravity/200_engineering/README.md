# 200_engineering
How Caption Studio is realized as software: the Electron process model and typed IPC, the project bundle
data model, local + OneDrive storage, the preview-to-export parity contract, and the testing standard.
This package implements the product knowledge (100) under the foundation rules (000). It is the bridge
between "what the product knows" and "what the code must guarantee."
