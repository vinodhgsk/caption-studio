# Storage — Local & OneDrive
A single `StorageProvider` interface backs both targets so editor code never branches on location:
list/create/read/write project, read media, write output, resolve path. **LocalProvider** uses the
filesystem with atomic writes. **OneDriveProvider** has two modes: synced-folder (treat the local
OneDrive path as a directory — simplest, recommended default) and Graph API (MSAL auth + Graph drive
items with a local cache and reconcile-on-reconnect, for projects not locally synced). Conflict policy is
last-write-wins with a warning, detected via updatedAt/etag. The bundle (002) stays self-contained so it
round-trips between locations without loss.
