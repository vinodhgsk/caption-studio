# Project Bundle Model
A project is a self-contained `.vproj` folder so it is portable across local disk and OneDrive:
`project.json` + `media/` + `cache/` + `exports/` + `media/fonts/`. `project.json` is the serialized
timeline: settings (fps, resolution, aspect), tracks[] of clips[], and the caption track whose clips
carry the text/caption model from 100_product_captioning/001. Writes are atomic (temp file + rename).
The bundle is the single unit of storage, versioning, and sharing; embedded fonts and cached
alignment/waveforms travel with it. This is the contract every feature reads and writes against.
