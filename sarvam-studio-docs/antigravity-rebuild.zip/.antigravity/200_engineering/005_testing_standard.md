# Testing Standard
Unit tests cover pure logic (timeline reducers, alignment grouping, keyframe/animation evaluators, the
IPC {ok,error} envelope on throw). E2E tests cover real flows (import → align → style → export). Providers
(STT/align/TTS) are mocked with deterministic fixtures. The quality gate is `npx vitest run` plus
`tsc --noEmit` and lint; it must run in CI and locally before any knowledge/code change merges (000/004).
Indic correctness has dedicated tests (no cluster splitting in karaoke/active-word) because it is a
release blocker. A green gate means "compiles and passes tests," not "verified" — milestone features are
also verified by eye (e.g. Tamil alignment) per 400_governance.
