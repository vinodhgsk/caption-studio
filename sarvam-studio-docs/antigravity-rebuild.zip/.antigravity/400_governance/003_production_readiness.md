# Production Readiness
Before a release: all quality gates green (001); export parity verified on real projects; Indic karaoke
verified by eye on Tamil/Telugu/Malayalam/Hindi songs; crash-safe autosave and corrupt-bundle recovery
tested; OneDrive offline/reconnect tested; large-project and long-audio stress passed; packaging signed
(Windows/macOS) with an update path; first-run onboarding (storage choice, model download) works offline
where promised; RELEASE checklist completed and versioned. Readiness is a checklist with evidence, not a
sign-off from memory.
