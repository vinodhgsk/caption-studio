# Quality Gates
Two enforceable gates. **Knowledge gate:** `node .antigravity/scripts/validate.mjs` — valid descriptors,
registry↔folders consistency, no dependency cycles, no stubs, no Mermaid. **Product gate:** `vitest run`
+ `tsc --noEmit` + lint + render-parity + Indic cluster checks. Both run in CI and must pass before merge;
no build step advances past a failing gate (300/003). Gates are the mechanical enforcement of the
foundation principles — governance that is stated but not gated is not governance.
