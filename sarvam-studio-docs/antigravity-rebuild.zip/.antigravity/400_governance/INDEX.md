# 400_governance — Index
- 001_quality_gates.md — the enforceable gates (repo validation + product tests + parity + Indic)
- 002_security_architecture.md — desktop/IPC/storage/provider security
- 003_production_readiness.md — the readiness checklist before shipping
- 004_versioning_traceability.md — semver, ADRs, provenance
