# Versioning & Traceability
Every Knowledge Package is semver-versioned in its descriptor; breaking a `provides[]` contract is a major
bump and requires an ADR when it affects dependents. Decisions live as ADRs in 000_foundation/adr and are
referenced via `conformsTo`. Generated artifacts record their input package ids and generator (manifest
schema) so any output is traceable back to the knowledge that produced it. Knowledge and the code/artifacts
it governs move together through PRs; the registry is regenerated from descriptors so it never drifts.
