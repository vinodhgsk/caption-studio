# Security Architecture
Caption Studio is a desktop app with filesystem and OneDrive access, so the threat surface is local and
cloud, not a public web server. Controls: strict Electron isolation (contextIsolation on, nodeIntegration
off, sandbox on; only a typed preload bridge — 200/001); no arbitrary shell from the renderer; media/file
access confined to the project bundle and chosen storage roots; OneDrive Graph tokens stored via OS secure
storage, least-scope, refreshable, revocable; imported fonts/media validated; no telemetry without consent.
Provider sidecars (align/STT/TTS) run in main with bounded inputs. Supply-chain: dependency review and
`npm audit` before release (500/002).
