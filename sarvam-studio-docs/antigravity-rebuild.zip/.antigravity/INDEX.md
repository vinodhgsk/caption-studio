# Master Index (generated-style)

> This index mirrors `registry/registry.json`. Regenerate from the registry; do not hand-drift.

## Backbone
- STANDARD.md — governing standard (EKPS 2.0)
- registry/registry.json — machine-readable package registry
- registry/knowledge-graph.json — nodes + edges
- schemas/package.meta.schema.json — package descriptor schema
- schemas/manifest.schema.json — build/generation manifest schema
- scripts/validate.mjs — enforcement gate
- diagrams/knowledge_domain_map.drawio — domain map

## Domains
- 000_foundation — charter, principles, naming, docs-as-code, diagram standard, ADRs, glossary
- 100_product_captioning — caption model, Indic/Tamil, forced alignment, styles/effects/transitions, karaoke
- 200_engineering — Electron architecture, project bundle, storage, export parity, testing
- 300_ai_factory — agent/skill/command/hook + autopilot runbook conventions
- 400_governance — governance, quality gates, security, production readiness, traceability
- 500_operations — observability, release, packaging/deployment
