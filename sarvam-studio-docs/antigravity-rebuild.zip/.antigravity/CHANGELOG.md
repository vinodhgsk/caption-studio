# CHANGELOG
## 2.0.0 — Full rebuild
- Replaced the over-scoped enterprise-factory blueprint with a right-sized Caption Studio knowledge repo.
- Added machine-readable backbone: package.meta.json per domain, registry.json, knowledge-graph.json, JSON Schemas.
- Added scripts/validate.mjs enforcement gate (no stubs, no Mermaid, no dependency cycles, registry↔folders).
- Adopted draw.io as the sole diagram standard; added real .drawio diagrams; removed all Mermaid.
- Eliminated the authoritative/archive duplication (single source of truth).
- Standardized naming (NNN_snake_case domains + docs).
