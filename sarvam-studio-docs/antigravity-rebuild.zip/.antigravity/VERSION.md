# VERSION
repository: caption-studio-knowledge
version: 2.0.0
standard: EKPS 2.0
status: Active
supersedes: 1.x (enterprise-factory blueprint, retired)
