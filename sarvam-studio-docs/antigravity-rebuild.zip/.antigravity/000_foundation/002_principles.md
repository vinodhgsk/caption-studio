# Principles (enforced)

1. Knowledge is the primary asset and is machine-readable — human prose in `.md`, machine truth in
   `package.meta.json` and `registry/`.
2. Single source of truth — a fact lives in exactly one package; duplication is a defect.
3. Docs-as-code — reviewed by PR, versioned with semver, changelogged.
4. Compiler-ready — every package declares identity, dependencies, and outputs as data.
5. draw.io is the only diagram standard; Mermaid is prohibited (ADR-001).
6. Validation is mandatory — `scripts/validate.mjs` gates the repo and runs in CI.
7. No stubs — placeholder files are not committed; empty structure is generated on demand, not stored.
8. Right-sized — the repository grows with real need, not with speculative empty scaffolding.
These principles are enforced mechanically where possible; the gate fails the build when they are violated.
