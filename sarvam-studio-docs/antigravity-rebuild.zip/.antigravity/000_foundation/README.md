# 000_foundation

The governing package. It defines the rules the rest of the repository obeys: the charter (why this
knowledge repo exists), the principles, the naming standard, the docs-as-code workflow, the diagram
standard (draw.io only), the decision log (ADRs), and the shared glossary. Nothing here depends on any
other package; everything else conforms to it. If a rule is contested, it is resolved by adding or
superseding an ADR under `adr/`, never by ad-hoc divergence.
