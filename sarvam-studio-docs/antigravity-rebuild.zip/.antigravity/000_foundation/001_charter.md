# Charter

This repository is the single, governed source of knowledge for Caption Studio — an Indic-first,
lyrics-driven caption editor for music videos. It exists so that the product, the engineering platform,
the AI build pipeline, governance, and operations are described once, machine-readably, and kept
consistent. It is deliberately scoped to this product, not to a hypothetical multi-product factory:
scope follows need. Knowledge here drives generation and review; it is not marketing or aspiration.
Success is measured by whether a competent engineer or agent can build and operate the product correctly
using only this repository plus the code it references, with the validation gate passing at all times.
