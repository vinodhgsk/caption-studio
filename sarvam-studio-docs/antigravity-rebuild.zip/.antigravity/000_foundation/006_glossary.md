# Glossary

- **Knowledge Package** — the smallest independently governed, versioned, machine-describable unit of
  knowledge (a domain folder with `package.meta.json` + docs).
- **EKPS** — Enterprise Knowledge Package Standard (this repo's governing standard, v2.0).
- **Descriptor** — `package.meta.json`, the machine-readable identity/deps/outputs of a package.
- **Gate** — `scripts/validate.mjs`, the enforcement check.
- **Akshara / grapheme cluster** — the atomic Indic text unit; never split for timing, coloring, or layout.
- **Forced alignment** — computing timing for KNOWN lyrics against audio (vs open transcription).
- **Parity** — preview render == FFmpeg export render, to the frame.
- **AI factory** — the agent/skill/command/hook + autopilot pipeline (in `.claude/`) that builds the app.
