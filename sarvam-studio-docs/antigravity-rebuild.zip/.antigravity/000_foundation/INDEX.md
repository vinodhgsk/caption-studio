# 000_foundation — Index
- 001_charter.md — why this repository exists and what it governs
- 002_principles.md — the enforced principles (knowledge-as-asset, single source of truth, compiler-ready)
- 003_naming_standard.md — naming + ID conventions
- 004_docs_as_code.md — the PR/versioning/validation workflow
- 005_diagram_standard.md — draw.io as the only diagram format (Mermaid prohibited)
- 006_glossary.md — shared terms
- adr/ — architecture decision records (ADR-001..003)
