# ADR-001 — draw.io is the diagram standard; Mermaid is prohibited
**Status:** Accepted **Date:** 2.0.0

## Context
Diagrams must be first-class, reviewable, and tool-consistent. The previous repository declared draw.io
as the standard yet contained a 24 KB Mermaid standard and Mermaid-based specs, and shipped zero `.drawio`
files — the decision was stated but not enforced.

## Decision
All diagrams are `.drawio` (mxGraph XML), edited with the VS Code Draw.io Integration extension. Mermaid
is prohibited in any form. The validation gate fails on `.mmd`/`.mermaid` files or ```mermaid fences.

## Consequences
Decision is mechanically enforced. Existing Mermaid content is not migrated in — it is removed. Diagrams
are committed as diffable XML sources; raster/vector exports are build artifacts only.
