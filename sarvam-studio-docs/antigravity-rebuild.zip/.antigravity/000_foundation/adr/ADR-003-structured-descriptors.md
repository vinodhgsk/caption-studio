# ADR-003 — Structured, machine-readable descriptors
**Status:** Accepted **Date:** 2.0.0

## Context
The prior repo was prose-only (0 JSON/YAML), so nothing could be compiled, validated, or graphed
deterministically — fatal for a "compiler-generated" vision.

## Decision
Every package carries `package.meta.json` conforming to `schemas/package.meta.schema.json`. The repo is
indexed by `registry/registry.json` and `registry/knowledge-graph.json`. JSON is chosen over YAML so the
validator and future compiler run dependency-free on Node.

## Consequences
Dependencies, ownership, and outputs are queryable data. Cycle detection, registry↔folder consistency,
and index generation are automatable. Prose remains the human view atop this structured spine.
