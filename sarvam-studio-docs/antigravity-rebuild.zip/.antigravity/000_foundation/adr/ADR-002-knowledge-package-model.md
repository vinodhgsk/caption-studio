# ADR-002 — Knowledge Package model, right-sized
**Status:** Accepted **Date:** 2.0.0

## Context
The prior repo used an over-scoped 35-domain "enterprise factory" layout that was ~93% empty stubs with
cloned skeletons, misrepresenting completeness.

## Decision
Adopt the Knowledge Package model but scope domains to what Caption Studio actually needs (six domains).
Every package has real content; empty scaffolding is not committed (enforced by the no-stub gate).

## Consequences
The tree reflects reality. New domains are added only when there is real knowledge to hold, and are
generated with content, not as placeholders.
