# Diagram Standard — draw.io only

All diagrams in this repository are draw.io files (`.drawio`, mxGraph XML), authored and edited with the
VS Code Draw.io Integration extension. This is a final decision recorded in ADR-001.

Rules:
- Diagrams live in a package's `diagrams/` folder (or the shared root `diagrams/`) and are referenced
  from `package.meta.json.diagrams[]`.
- `.drawio` XML is committed as source — it is diffable and reviewable; exported PNG/SVG are build
  artifacts, not sources, and are not committed to the knowledge tree.
- **Mermaid is prohibited.** No `.mmd`/`.mermaid` files, and no ```mermaid fenced blocks in Markdown.
  The validation gate fails the build on any Mermaid usage — this is how the decision is enforced rather
  than merely stated (the prior repository violated its own draw.io decision; this rebuild does not).
