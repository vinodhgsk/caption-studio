# Documentation-as-Code

Knowledge is changed the way code is changed. Every modification is a pull request against this
repository. A change is mergeable only when `node .antigravity/scripts/validate.mjs` exits 0 (the same
gate CI runs). Each package carries its own semantic version in `package.meta.json`; breaking a declared
`provides[]` contract requires a major bump and an ADR if it affects other packages. Human-readable
prose and machine-readable descriptors are edited together and never allowed to drift — the registry is
regenerated from the descriptors, not hand-maintained. Diagrams are edited as `.drawio` via the VS Code
Draw.io Integration extension and committed as source (they are diffable XML), not exported images.
