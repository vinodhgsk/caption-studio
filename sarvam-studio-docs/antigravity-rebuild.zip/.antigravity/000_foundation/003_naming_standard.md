# Naming Standard

- Domains and content documents use `NNN_snake_case`: a 3-digit zero-padded numeric ID followed by
  lowercase snake_case (e.g. `100_product_captioning`, `003_lyrics_first_forced_alignment.md`).
- The numeric prefix is a STABLE IDENTIFIER, not a sort key. Navigation is via `INDEX.md` and the
  registry/graph, so re-ordering never requires renaming.
- Infrastructure directories are unnumbered and lowercase: `registry/`, `schemas/`, `scripts/`, `diagrams/`.
- Well-known root files are UPPERCASE: `README.md`, `INDEX.md`, `STANDARD.md`, `VERSION.md`,
  `CHANGELOG.md`, `KNOWLEDGE_MAP.md`.
- Package descriptor is always `package.meta.json` (never `package.json`, to avoid clashing with npm).
- Diagram files are `*.drawio`. Decision records are `adr/ADR-NNN-kebab-title.md`.
Consistency here is what lets the compiler and validator reason about the tree deterministically.
