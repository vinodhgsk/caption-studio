# Knowledge Map (human view)

Caption Studio's knowledge is organized as six governed domains plus a machine-readable backbone.
Read top-down for onboarding; the compiler/tools read `registry/` and each `package.meta.json`.

- **000_foundation** — the rules of the repo: charter, principles, naming, docs-as-code, the draw.io
  diagram standard, decision records (ADRs), glossary. Everything else conforms to this.
- **100_product_captioning** — WHAT the product knows: caption data model, Indic/Tamil-first rules,
  lyrics-first forced alignment, caption styles/effects/transitions, karaoke & active-word.
- **200_engineering** — HOW it is built as software: Electron process model, project bundle model,
  local/OneDrive storage, preview↔export parity, testing standard.
- **300_ai_factory** — HOW it is built by AI: agent/skill/command/hook conventions and the autopilot
  runbook model (this domain governs the `.claude/` pipeline).
- **400_governance** — quality gates, security architecture, production readiness, versioning & traceability.
- **500_operations** — observability, release, packaging & deployment.

Dependency direction flows downward only: product/engineering/ai-factory conform to foundation;
governance & operations observe all. No cycles (enforced by validate.mjs).
