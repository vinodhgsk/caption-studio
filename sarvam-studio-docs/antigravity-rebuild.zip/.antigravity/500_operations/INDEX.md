# 500_operations — Index
- 001_observability.md — health + provenance signals for a desktop, AI-built product
- 002_release_process.md — versioned, gated release flow
- 003_packaging_deployment.md — electron-builder packaging + update path
