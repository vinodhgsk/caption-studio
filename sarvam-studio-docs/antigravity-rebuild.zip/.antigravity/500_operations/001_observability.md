# Observability
For a desktop app the signals are local, plus build-time provenance. Capture (with consent): crash reports
and unhandled IPC errors; forced-alignment confidence and fallback usage; export success/parity-diff
metrics; performance (timeline/preview frame times, long-audio memory). Build-time: generation provenance
— which knowledge packages and generator produced each artifact (400/004) — so a regression can be traced
to the knowledge that caused it. No silent telemetry; opt-in and documented (400/002).
