# Release Process
A release is cut only when production readiness (400/003) and both quality gates (400/001) pass. Steps:
bump versions, update CHANGELOGs, run the full gate + e2e + parity + Indic verification, build signed
packages, smoke-test the packaged app on each platform (including a Tamil alignment + export flow), tag,
then publish with release notes tracing included knowledge/artifact versions. Rollback = re-publish the
prior signed build; projects are forward/backward compatible via the bundle version field.
