# 500_operations
Running and shipping the product: what we observe (build/generation provenance, alignment/export health,
crashes), how we release (versioned, checklisted, gated), and how we package and deploy the Electron app
across platforms. Right-sized for a desktop application — no server fleet — but explicit about the
provenance and health signals that keep an AI-generated product trustworthy.
