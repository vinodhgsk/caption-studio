# Packaging & Deployment
Packaged with electron-builder for Windows and macOS. Native/bundled resources (FFmpeg, alignment/STT
models, default fonts) are either bundled or downloaded on first run with an offline-capable fallback
where promised (400/003). Code-signing per platform; an auto-update channel with signed updates. First-run
onboarding sets storage location (local/OneDrive) and fetches any large models. Deployment is distribution
of a signed desktop artifact — there is no server runtime to operate — which keeps operations lean.
