# Lyrics-First Forced Alignment (the captioning method)

Open auto-transcription of sung Indic vocals is unreliable (wrong words and wrong timing). Because the
user knows the lyrics, we remove the hard half: the user supplies the exact lyrics for the chosen
language and the system computes only the timing — forced alignment.

Pipeline (see diagrams/caption_pipeline.drawio):
1. FFmpeg → 16kHz mono; optional vocal isolation (biggest accuracy win for music); VAD for sung regions.
2. Parse lyrics into lines → words → aksharas (002).
3. Forced alignment (recommended: CTC with a multilingual model supporting ta/te/ml/hi, native script;
   alternatives MFA, or Aeneas TTS+DTW at line level) behind a provider interface, local-first.
4. Confidence scoring; Tap-Sync anchors + proportional fallback for regions alignment misses.
5. Emit caption clips with word/syllable timings; cache the alignment; frame-snap on emit for parity.
Words are user-owned: editing changes timing, never text; editing text is an explicit re-align.
Full spec detail lives in the product doc `LYRICS_FIRST_FORCED_ALIGNMENT_CAPTIONING.md` referenced by
this package.
