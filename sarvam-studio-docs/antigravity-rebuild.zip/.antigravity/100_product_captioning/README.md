# 100_product_captioning

The core product knowledge. Caption Studio turns a music track plus known lyrics into precisely-timed,
premium captions in Indic scripts (Tamil primary; Telugu, Malayalam, Hindi) and English. This package
defines the caption data model, the non-negotiable Indic text rules, the lyrics-first forced-alignment
approach (replacing unreliable open transcription), the styling system (styles, effects, transitions),
and karaoke / active-word behavior. It conforms to 000_foundation and is the source that 200_engineering
implements and 300_ai_factory automates.
