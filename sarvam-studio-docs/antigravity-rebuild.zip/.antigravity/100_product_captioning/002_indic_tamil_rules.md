# Indic / Tamil Rules (release blocker)

Caption Studio is Indic-first. Correct rendering and segmentation are a release blocker — broken clusters
make the product unusable for its audience.

Supported: Tamil `ta` (primary/default), Telugu `te`, Malayalam `ml`, Hindi `hi` (Devanagari), English `en`.

The cardinal rule: the **akshara / extended grapheme cluster** is atomic. A perceived character (e.g.
Tamil கி, க்ஷ; Devanagari क्षि) is multiple code points. Never split, index, break, color, time, or
animate below the cluster. Prohibited on Indic text: `split('')`, `text[i]`/`charAt`/`codePointAt` for
per-character logic, mid-cluster line breaks, half-cluster karaoke highlight. Use complex-script shaping
(HarfBuzz-class) for layout and a script-aware syllabifier for karaoke. This rule binds every downstream
feature: alignment (003), styles (004), karaoke/active-word (005), and their engineering implementation.
