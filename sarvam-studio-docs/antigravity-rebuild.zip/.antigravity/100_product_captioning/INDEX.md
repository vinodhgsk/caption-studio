# 100_product_captioning — Index
- 001_caption_domain_model.md — the caption/text data model (contract shared with the app)
- 002_indic_tamil_rules.md — grapheme-cluster rules; Tamil/Telugu/Malayalam/Hindi (release blocker)
- 003_lyrics_first_forced_alignment.md — user-provided lyrics aligned to audio (the captioning method)
- 004_styles_effects_transitions.md — premium caption styles, text effects, caption transitions
- 005_karaoke_active_word.md — word-by-word reveal, active-word highlight, karaoke roll-up
- diagrams/caption_pipeline.drawio — the lyrics-first pipeline
