# Caption Styles, Text Effects & Caption Transitions

Premium output for music videos is delivered by three composable, registry-based systems, all built from
reusable text primitives (typography, fill/stroke/shadow, decoration, animation) and all rendered
identically in preview and export.

- **Caption presets** — genre/mood bundles (EDM, hip-hop, pop, lo-fi, rock, cinematic, lyric-video,
  Indic/Tamil-film, retro, acoustic) that stamp a full look onto the caption track in one click. Indic
  presets pick Indic-capable fonts and advance highlight by akshara.
- **Text effects** — a composable effect stack (glow/neon/glitch/3D/retro/blur/echo plus premium
  treatments) registered as effect types; seeded and offscreen-rendered for export parity.
- **Caption transitions** — swaps between consecutive lyric lines (cross-dissolve, lyric-push,
  karaoke-rollup, beat-cut, etc.), distinct from clip transitions, over an overlap window.
All are additive registries: adding a preset/effect/transition never alters existing ones.
