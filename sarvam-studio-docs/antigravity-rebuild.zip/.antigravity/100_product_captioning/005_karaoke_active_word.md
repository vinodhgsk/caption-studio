# Karaoke & Active-Word

Two timing-driven presentations sit on top of the alignment (003) and the Indic rules (002):
- **Word-by-word reveal** — each word appears at its `wordTimings[].start`.
- **Active-word highlight** — the word whose `[start,end]` contains the playhead changes color/scale/fill,
  evaluated per frame (not baked) so edits update it live; must track audio within ±1 frame.
- **Karaoke roll-up** — a 2–3 line stack where the active line rises and fills per syllable using
  `syllableTimings`; syllable = akshara, so Tamil fills correctly and never mid-cluster.
Acceptance: on a Tamil song, syllable fill and active-word land within ±1 frame and no cluster is split.
These behaviors are consumed by the caption presets (004) and the AI factory's caption agents (300).
