# Caption Domain Model

A project has a caption track of caption clips. Each caption clip carries text plus timing derived from
the audio. The text model is per-run styled so partial styling (e.g. one highlighted word) works.

Key entities (the contract 200_engineering implements as `project.json`):
- **Caption clip**: `{ content, start, end, text{ runs[], style, layout, decoration }, caption{ styleId, wordTimings[], syllableTimings[], activeWord } }`.
- **Timing** is always frame-snapped and expressed in seconds; `wordTimings`/`syllableTimings` come from
  forced alignment (003) and drive karaoke/active-word (005).
- **Styling** (fill/stroke/shadow/effects/animation/decoration) is composed from reusable primitives and
  captured by caption presets (004).
Invariants: timings are monotonic and non-overlapping within a clip; every syllable maps to a source
akshara (002); preview timing equals export timing (parity, see 200_engineering/004).
